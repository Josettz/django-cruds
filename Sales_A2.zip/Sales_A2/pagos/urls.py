from django.urls import path
from . import views

app_name = 'pagos'

urlpatterns = [
    path('', views.CompraPendienteListView.as_view(), name='compra_pendiente_list'),
    path('compra/<int:pk>/', views.CompraPagoDetailView.as_view(), name='compra_detail'),
    path('registrar/', views.pago_create, name='pago_create'),
    path('historial/', views.HistorialPagosListView.as_view(), name='historial_list'),
    path('<int:pk>/editar/', views.PagoUpdateView.as_view(), name='pago_update'),
    path('<int:pk>/eliminar/', views.PagoDeleteView.as_view(), name='pago_delete'),
]
