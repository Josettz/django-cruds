from django import forms
from django.db.models import Q
from purchasing.models import Purchase
from .models import PagoCompra


class PagoCompraForm(forms.ModelForm):
    class Meta:
        model = PagoCompra
        fields = ['compra', 'fecha', 'valor', 'observacion']
        widgets = {
            'compra': forms.Select(attrs={'class': 'form-select'}),
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'valor': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}),
            'observacion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        qs = Purchase.objects.exclude(estado='anulada')
        if self.instance.pk:
            qs = qs.filter(Q(saldo__gt=0) | Q(pk=self.instance.compra_id))
        else:
            qs = qs.filter(saldo__gt=0)
        self.fields['compra'].queryset = qs

    def clean(self):
        cleaned = super().clean()
        compra = cleaned.get('compra')
        valor = cleaned.get('valor')
        if not compra or valor is None:
            return cleaned

        if valor <= 0:
            raise forms.ValidationError('El valor del pago debe ser mayor que cero.')

        if compra.estado == 'anulada':
            raise forms.ValidationError('No se puede registrar un pago sobre una compra anulada.')

        saldo_disponible = compra.saldo
        if self.instance.pk and self.instance.compra_id == compra.id:
            saldo_disponible += self.instance.valor

        if valor > saldo_disponible:
            raise forms.ValidationError(
                f'El pago (${valor}) no puede ser mayor al saldo pendiente (${saldo_disponible}).'
            )
        return cleaned
