from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, UpdateView, DeleteView, DetailView

from purchasing.models import Purchase
from .models import PagoCompra
from .forms import PagoCompraForm


def _recalcular_compra(compra):
    """Recalcula saldo y estado de la compra desde cero, sumando sus pagos vigentes."""
    total_pagado = sum((p.valor for p in compra.pagos.all()), start=0)
    compra.saldo = compra.total - total_pagado
    if compra.saldo <= 0:
        compra.saldo = 0
        compra.estado = 'pagada'
    else:
        compra.estado = 'pendiente'
    compra.save(update_fields=['saldo', 'estado'])


class CompraPendienteListView(LoginRequiredMixin, ListView):
    model = Purchase
    template_name = 'pagos/compra_pendiente_list.html'
    context_object_name = 'compras'
    paginate_by = 10

    def get_queryset(self):
        return (
            Purchase.objects.select_related('supplier')
            .filter(saldo__gt=0)
            .exclude(estado='anulada')
            .order_by('-purchase_date')
        )


class HistorialPagosListView(LoginRequiredMixin, ListView):
    model = PagoCompra
    template_name = 'pagos/historial_list.html'
    context_object_name = 'items'
    paginate_by = 15

    def get_queryset(self):
        qs = PagoCompra.objects.select_related('compra', 'compra__supplier').order_by('-fecha', '-id')
        compra_id = self.request.GET.get('compra')
        if compra_id:
            qs = qs.filter(compra_id=compra_id)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        compra_id = self.request.GET.get('compra')
        ctx['compra_filtrada'] = (
            Purchase.objects.filter(pk=compra_id).first() if compra_id else None
        )
        return ctx


@transaction.atomic
def pago_create(request):
    compra_inicial = request.GET.get('compra')
    if request.method == 'POST':
        form = PagoCompraForm(request.POST)
        if form.is_valid():
            pago = form.save()
            _recalcular_compra(pago.compra)
            messages.success(
                request,
                f'Pago de ${pago.valor} registrado sobre la Compra #{pago.compra_id}. '
                f'Saldo actual: ${pago.compra.saldo} ({pago.compra.get_estado_display()}).'
            )
            return redirect('pagos:compra_pendiente_list')
    else:
        initial = {}
        if compra_inicial:
            initial['compra'] = compra_inicial
        form = PagoCompraForm(initial=initial)
    return render(request, 'pagos/pago_form.html', {'form': form, 'title': 'Registrar Pago'})


class PagoUpdateView(LoginRequiredMixin, UpdateView):
    model = PagoCompra
    form_class = PagoCompraForm
    template_name = 'pagos/pago_form.html'
    success_url = reverse_lazy('pagos:historial_list')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['title'] = 'Editar Pago'
        return ctx

    @transaction.atomic
    def form_valid(self, form):
        compra_anterior = self.get_object().compra
        response = super().form_valid(form)
        _recalcular_compra(compra_anterior)
        _recalcular_compra(self.object.compra)
        messages.success(self.request, 'Pago actualizado y saldo recalculado.')
        return response


class PagoDeleteView(LoginRequiredMixin, DeleteView):
    model = PagoCompra
    template_name = 'pagos/pago_confirm_delete.html'
    success_url = reverse_lazy('pagos:historial_list')

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        compra = self.object.compra
        if compra.estado == 'pagada':
            messages.error(
                request,
                'No se puede eliminar este pago: la compra ya está totalmente cancelada.'
            )
            return redirect(self.success_url)
        self.object.delete()
        _recalcular_compra(compra)
        messages.success(request, 'Pago eliminado y saldo recalculado correctamente.')
        return redirect(self.success_url)


class CompraPagoDetailView(LoginRequiredMixin, DetailView):
    model = Purchase
    template_name = 'pagos/compra_detail.html'
    context_object_name = 'compra'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['pagos'] = self.object.pagos.all()
        ctx['pagado'] = self.object.total - self.object.saldo
        return ctx
