from django.contrib import admin
from .models import PagoCompra


@admin.register(PagoCompra)
class PagoCompraAdmin(admin.ModelAdmin):
    list_display = ('compra', 'fecha', 'valor')
    list_filter = ('fecha',)
    search_fields = ('compra__id', 'observacion')
