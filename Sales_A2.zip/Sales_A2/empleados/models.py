from django.db import models
from departamento.models import Departamento
from shared.validators import validate_cedula_ec
# Create your models here.

class Empleado(models.Model):
    CARGO_CHOICES = [
        ('vendedor', 'Vendedor'),
        ('bodeguero', 'Bodeguero'),
        ('administrador', 'Administrador'),
        ('contador', 'Contador'),
    ]

    cedula = models.CharField(max_length=13, unique=True, verbose_name='Cédula', validators=[validate_cedula_ec])
    first_name = models.CharField(max_length=100, verbose_name='Nombres')
    last_name = models.CharField(max_length=100, verbose_name='Apellidos')
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name='Teléfono')
    cargo = models.CharField(max_length=20, choices=CARGO_CHOICES, default='vendedor')
    departamento = models.ForeignKey(Departamento, on_delete=models.PROTECT, related_name='empleados', verbose_name='Departamento') 
    salary = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Salario')
    hire_date = models.DateField(verbose_name='Fecha de contratación')
    is_active = models.BooleanField(default=True, verbose_name='Activo')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['last_name', 'first_name']
    
    def __str__(self):
        return f'{self.last_name}, {self.first_name}'
    
    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'