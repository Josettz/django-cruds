from django.shortcuts import render

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView

from .models import Empleado
from .forms import EmpleadoForm
from billing.mixins import ExportMixin
# Create your views here.

class EmpleadoListView(ExportMixin, LoginRequiredMixin, ListView):
    model = Empleado
    template_name = 'empleados/empleado_list.html'
    context_object_name = 'items'
    paginate_by = 5 
    export_filename = 'Empleados'
    export_fields = [
        ('cedula', 'Cédula'),
        ('full_name', 'Nombre completo'),
        ('get_cargo_display', 'Cargo'),
        ('salary', 'Salario'),
        ('hire_date', 'Fecha contratación'),
    ]

class EmpleadoDetailView(LoginRequiredMixin, DetailView):
    model = Empleado
    template_name = 'empleados/empleado_detail.html'
    context_object_name = 'empleado'

class EmpleadoCreateView(LoginRequiredMixin, CreateView):
    model = Empleado
    form_class = EmpleadoForm
    template_name = 'empleados/empleado_form.html'
    success_url = reverse_lazy('empleados:empleado_list')

    def form_valid(self, form):
        messages.success(self.request, f'Empleado "{form.instance.full_name}" creado exitosamente.')
        return super().form_valid(form)

class EmpleadoUpdateView(LoginRequiredMixin, UpdateView):
    model = Empleado
    form_class = EmpleadoForm
    template_name = 'empleados/empleado_form.html'
    success_url = reverse_lazy('empleados:empleado_list')

    def form_valid(self, form):
        messages.success(self.request, f'Empleado "{form.instance.full_name}" actualiazado exitosamente.')
        return super().form_valid(form)
    
class EmpleadoDeleteView(LoginRequiredMixin, DeleteView):
    model = Empleado
    template_name = 'empleados/empleado_confirm_delete.html'
    success_url = reverse_lazy('empleados:empleado_list')
