from django.urls import path
from . import views

app_name = 'cobros'

urlpatterns = [
    path('', views.FacturaPendienteListView.as_view(), name='factura_pendiente_list'),
    path('factura/<int:pk>/', views.FacturaCobroDetailView.as_view(), name='factura_detail'),
    path('registrar/', views.cobro_create, name='cobro_create'),
    path('historial/', views.HistorialPagosListView.as_view(), name='historial_list'),
    path('<int:pk>/editar/', views.CobroUpdateView.as_view(), name='cobro_update'),
    path('<int:pk>/eliminar/', views.CobroDeleteView.as_view(), name='cobro_delete'),
]
