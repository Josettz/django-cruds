from django.db import models
from billing.models import Invoice


class CobroFactura(models.Model):
    """Registra un abono de un cliente sobre una factura de venta a crédito."""
    factura = models.ForeignKey(
        Invoice, on_delete=models.PROTECT, related_name='cobros',
        verbose_name='Factura'
    )
    fecha = models.DateField(verbose_name='Fecha del pago')
    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Valor abonado')
    observacion = models.TextField(blank=True, verbose_name='Observación')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Cobro de Factura'
        verbose_name_plural = 'Cobros de Facturas'
        ordering = ['-fecha', '-id']

    def __str__(self):
        return f'Cobro ${self.valor} - Factura #{self.factura_id}'
