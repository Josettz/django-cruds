from django.contrib import admin
from .models import CobroFactura


@admin.register(CobroFactura)
class CobroFacturaAdmin(admin.ModelAdmin):
    list_display = ('factura', 'fecha', 'valor')
    list_filter = ('fecha',)
    search_fields = ('factura__id', 'observacion')
