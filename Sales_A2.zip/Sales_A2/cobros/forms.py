from django import forms
from django.db.models import Q
from billing.models import Invoice
from .models import CobroFactura


class CobroFacturaForm(forms.ModelForm):
    class Meta:
        model = CobroFactura
        fields = ['factura', 'fecha', 'valor', 'observacion']
        widgets = {
            'factura': forms.Select(attrs={'class': 'form-select'}),
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'valor': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}),
            'observacion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Solo se pueden elegir facturas no anuladas.
        qs = Invoice.objects.exclude(estado='anulada')
        if self.instance.pk:
            # Al editar: la factura ya asignada debe seguir apareciendo en la
            # lista aunque su saldo actual (con este pago ya descontado) sea 0.
            qs = qs.filter(Q(saldo__gt=0) | Q(pk=self.instance.factura_id))
        else:
            qs = qs.filter(saldo__gt=0)
        self.fields['factura'].queryset = qs

    def clean(self):
        cleaned = super().clean()
        factura = cleaned.get('factura')
        valor = cleaned.get('valor')
        if not factura or valor is None:
            return cleaned

        if valor <= 0:
            raise forms.ValidationError('El valor del pago debe ser mayor que cero.')

        if factura.estado == 'anulada':
            raise forms.ValidationError('No se puede registrar un pago sobre una factura anulada.')

        # saldo disponible = saldo actual; si se está EDITANDO este mismo cobro
        # sobre la MISMA factura, se le devuelve su valor viejo antes de comparar
        # (para no autobloquearse con su propio pago anterior).
        saldo_disponible = factura.saldo
        if self.instance.pk and self.instance.factura_id == factura.id:
            saldo_disponible += self.instance.valor

        if valor > saldo_disponible:
            raise forms.ValidationError(
                f'El pago (${valor}) no puede ser mayor al saldo pendiente (${saldo_disponible}).'
            )
        return cleaned
