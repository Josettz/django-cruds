from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import ListView, UpdateView, DeleteView, DetailView

from billing.models import Invoice
from .models import CobroFactura
from .forms import CobroFacturaForm


def _recalcular_factura(factura):
    """
    Recalcula saldo y estado de la factura sumando TODOS sus cobros vigentes.
    Se recalcula desde cero (en vez de sumar/restar incrementalmente) para que
    nunca quede inconsistente, sin importar si el cambio vino de crear, editar
    o eliminar un pago.
    """
    total_pagado = sum((c.valor for c in factura.cobros.all()), start=0)
    factura.saldo = factura.total - total_pagado
    if factura.saldo <= 0:
        factura.saldo = 0
        factura.estado = 'pagada'
    else:
        factura.estado = 'pendiente'
    factura.save(update_fields=['saldo', 'estado'])


# === Lista de facturas pendientes de cobro ===
class FacturaPendienteListView(LoginRequiredMixin, ListView):
    model = Invoice
    template_name = 'cobros/factura_pendiente_list.html'
    context_object_name = 'facturas'
    paginate_by = 10

    def get_queryset(self):
        return (
            Invoice.objects.select_related('customer')
            .filter(saldo__gt=0)
            .exclude(estado='anulada')
            .order_by('-invoice_date')
        )


# === Historial de pagos (de todas las facturas, o filtrado por una) ===
class HistorialPagosListView(LoginRequiredMixin, ListView):
    model = CobroFactura
    template_name = 'cobros/historial_list.html'
    context_object_name = 'items'
    paginate_by = 15

    def get_queryset(self):
        qs = CobroFactura.objects.select_related('factura', 'factura__customer').order_by('-fecha', '-id')
        factura_id = self.request.GET.get('factura')
        if factura_id:
            qs = qs.filter(factura_id=factura_id)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        factura_id = self.request.GET.get('factura')
        ctx['factura_filtrada'] = (
            Invoice.objects.filter(pk=factura_id).first() if factura_id else None
        )
        return ctx


# === Registrar un pago ===
@transaction.atomic
def cobro_create(request):
    factura_inicial = request.GET.get('factura')
    if request.method == 'POST':
        form = CobroFacturaForm(request.POST)
        if form.is_valid():
            cobro = form.save()
            _recalcular_factura(cobro.factura)
            messages.success(
                request,
                f'Pago de ${cobro.valor} registrado sobre la Factura #{cobro.factura_id}. '
                f'Saldo actual: ${cobro.factura.saldo} ({cobro.factura.get_estado_display()}).'
            )
            return redirect('cobros:factura_pendiente_list')
    else:
        initial = {}
        if factura_inicial:
            initial['factura'] = factura_inicial
        form = CobroFacturaForm(initial=initial)
    return render(request, 'cobros/cobro_form.html', {'form': form, 'title': 'Registrar Pago'})


# === Editar un pago ===
class CobroUpdateView(LoginRequiredMixin, UpdateView):
    model = CobroFactura
    form_class = CobroFacturaForm
    template_name = 'cobros/cobro_form.html'
    success_url = reverse_lazy('cobros:historial_list')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['title'] = 'Editar Pago'
        return ctx

    @transaction.atomic
    def form_valid(self, form):
        factura_anterior = self.get_object().factura
        response = super().form_valid(form)
        _recalcular_factura(factura_anterior)
        _recalcular_factura(self.object.factura)
        messages.success(self.request, 'Pago actualizado y saldo recalculado.')
        return response


# === Eliminar un pago ===
class CobroDeleteView(LoginRequiredMixin, DeleteView):
    model = CobroFactura
    template_name = 'cobros/cobro_confirm_delete.html'
    success_url = reverse_lazy('cobros:historial_list')

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        factura = self.object.factura
        if factura.estado == 'pagada':
            messages.error(
                request,
                'No se puede eliminar este pago: la factura ya está totalmente cancelada. '
                'Eliminarlo dejaría el saldo inconsistente.'
            )
            return redirect(self.success_url)
        self.object.delete()
        _recalcular_factura(factura)
        messages.success(request, 'Pago eliminado y saldo recalculado correctamente.')
        return redirect(self.success_url)


# === Detalle de factura (opcional, útil para ver antes de cobrar) ===
class FacturaCobroDetailView(LoginRequiredMixin, DetailView):
    model = Invoice
    template_name = 'cobros/factura_detail.html'
    context_object_name = 'factura'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['cobros'] = self.object.cobros.all()
        ctx['pagado'] = self.object.total - self.object.saldo
        return ctx
