from django.db import models
from decimal import Decimal
from billing.models import Supplier, Product   # Reutilizamos modelos de billing


class Purchase(models.Model):
    """Cabecera de compra. Documenta una adquisición a un proveedor."""
    ESTADO_CHOICES = [
        ('pendiente', 'PENDIENTE'),
        ('pagada', 'PAGADA'),
        ('anulada', 'ANULADA'),
    ]
    supplier = models.ForeignKey(
        Supplier, on_delete=models.PROTECT, related_name='purchases',
        verbose_name='Proveedor'
    )
    document_number = models.CharField(
        max_length=20, verbose_name='Supplier Invoice No.'
    )
    purchase_date = models.DateTimeField(auto_now_add=True)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name='Impuesto')
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    saldo = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name='Saldo pendiente')
    estado = models.CharField(max_length=10, choices=ESTADO_CHOICES, default='pendiente', verbose_name='Estado')
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = 'Purchase'
        verbose_name_plural = 'Purchases'
        ordering = ['-purchase_date']
        constraints = [
            models.UniqueConstraint(
                fields=['supplier', 'document_number'],
                name='unique_supplier_document'
            )
        ]

    def __str__(self):
        return f'Purchase #{self.id} - {self.supplier}'


class PurchaseDetail(models.Model):
    """Líneas de compra. Cada fila es un producto adquirido."""
    purchase = models.ForeignKey(
        Purchase, on_delete=models.CASCADE, related_name='details',
        verbose_name='Compra'
    )
    product = models.ForeignKey(
        Product, on_delete=models.PROTECT, related_name='purchase_details',
        verbose_name='Producto'
    )
    quantity = models.PositiveIntegerField(default=1, verbose_name='Cantidad')
    unit_cost = models.DecimalField(max_digits=12, decimal_places=2, verbose_name='Costo unitario')
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f'{self.product.name} x {self.quantity}'

    def save(self, *args, **kwargs):
        self.subtotal = self.quantity * self.unit_cost
        super().save(*args, **kwargs)