from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('purchasing', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='purchase',
            name='saldo',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12, verbose_name='Saldo pendiente'),
        ),
        migrations.AddField(
            model_name='purchase',
            name='estado',
            field=models.CharField(
                choices=[('pendiente', 'PENDIENTE'), ('pagada', 'PAGADA'), ('anulada', 'ANULADA')],
                default='pendiente', max_length=10, verbose_name='Estado',
            ),
        ),
    ]
