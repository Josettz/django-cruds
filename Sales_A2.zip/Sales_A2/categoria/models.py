from django.db import models

# Create your models here.

class Categoria(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name='Nombre de Categoría')
    description = models.TextField(blank=True, null=True , verbose_name='Descripción')
    is_active = models.BooleanField(default=True, verbose_name='Activo')   

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f'{self.name}'
    
    @property
    def full_name(self):
        return f'{self.name}'