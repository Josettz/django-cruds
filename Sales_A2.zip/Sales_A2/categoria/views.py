from django.shortcuts import render

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView

from .models import Categoria
from .forms import CategoriaForm
from billing.mixins import ExportMixin
# Create your views here.

class CategoriaListView(ExportMixin, LoginRequiredMixin, ListView):
    model = Categoria 
    template_name = 'categoria/categoria_list.html'
    context_object_name = 'items'
    paginate_by = 5 
    export_filename = 'Categorías de Gastos'
    export_fields = [
        ('name', 'Nombre de Categoría'),
        ('description', 'Descripción'),
    ]

class CategoriaDetailView(LoginRequiredMixin, DetailView):
    model = Categoria
    template_name = 'categoria/categoria_detail.html'
    context_object_name = 'categoria'

class CategoriaCreateView(LoginRequiredMixin, CreateView):
    model = Categoria
    form_class = CategoriaForm
    template_name = 'categoria/categoria_form.html'
    success_url = reverse_lazy('categoria:categoria_list')

    def form_valid(self, form):
        messages.success(self.request, f'Categoría "{form.instance.full_name}" creado exitosamente.')
        return super().form_valid(form)

class CategoriaUpdateView(LoginRequiredMixin, UpdateView):
    model = Categoria
    form_class = CategoriaForm
    template_name = 'categoria/categoria_form.html'
    success_url = reverse_lazy('categoria:categoria_list')

    def form_valid(self, form):
        messages.success(self.request, f'Categoría "{form.instance.full_name}" actualiazado exitosamente.')
        return super().form_valid(form)
    
class CategoriaDeleteView(LoginRequiredMixin, DeleteView):
    model = Categoria
    template_name = 'categoria/categoria_confirm_delete.html'
    success_url = reverse_lazy('categoria:categoria_list')
