from django.urls import path 
from . import views

app_name = 'categoria'

urlpatterns = [
    path('', views.CategoriaListView.as_view(), name='categoria_list'),   
    path('<int:pk>/', views.CategoriaDetailView.as_view(), name='categoria_detail'),
    path('create/', views.CategoriaCreateView.as_view(), name='categoria_create'),
    path('<int:pk>/edit', views.CategoriaUpdateView.as_view(), name='categoria_update'),
    path('<int:pk>/delete/', views.CategoriaDeleteView.as_view(), name='categoria_delete'),
]