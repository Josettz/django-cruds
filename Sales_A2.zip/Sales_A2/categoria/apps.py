from django.apps import AppConfig


class CategoríaConfig(AppConfig):
    name = 'categoria'
