from django.shortcuts import render

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView

from .models import Departamento
from .forms import DepartamentoForm
from billing.mixins import ExportMixin
# Create your views here.

class DepartamentoListView(ExportMixin, LoginRequiredMixin, ListView):
    model = Departamento
    template_name = 'departamento/departamento_list.html'
    context_object_name = 'items'
    paginate_by = 5 
    export_filename = 'Departamento'
    export_fields = [
        ('name', 'Departamento'),
        ('description', 'Descripción'),
    ]

class DepartamentoDetailView(LoginRequiredMixin, DetailView):
    model = Departamento
    template_name = 'departamento/departamento_detail.html'
    context_object_name = 'departamento'

class DepartamentoCreateView(LoginRequiredMixin, CreateView):
    model = Departamento
    form_class = DepartamentoForm
    template_name = 'departamento/departamento_form.html'
    success_url = reverse_lazy('departamento:departamento_list')

    def form_valid(self, form):
        messages.success(self.request, f'Departamento "{form.instance.full_name}" creado exitosamente.')
        return super().form_valid(form)

class DepartamentoUpdateView(LoginRequiredMixin, UpdateView):
    model = Departamento
    form_class = DepartamentoForm
    template_name = 'departamento/departamento_form.html'
    success_url = reverse_lazy('departamento:departamento_list')

    def form_valid(self, form):
        messages.success(self.request, f'Departamento "{form.instance.full_name}" actualiazado exitosamente.')
        return super().form_valid(form)

class DepartamentoDeleteView(LoginRequiredMixin, DeleteView):
    model = Departamento
    template_name = 'departamento/departamento_confirm_delete.html'
    success_url = reverse_lazy('departamento:departamento_list')
