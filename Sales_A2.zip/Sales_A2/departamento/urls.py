from django.urls import path
from . import views   

app_name = 'departamento'

urlpatterns = [
    path('', views.DepartamentoListView.as_view(), name='departamento_list'),   
    path('<int:pk>/', views.DepartamentoDetailView.as_view(), name='departamento_detail'),
    path('create/', views.DepartamentoCreateView.as_view(), name='departamento_create'),
    path('<int:pk>/edit', views.DepartamentoUpdateView.as_view(), name='departamento_update'),
    path('<int:pk>/delete/', views.DepartamentoDeleteView.as_view(), name='departamento_delete'),
]