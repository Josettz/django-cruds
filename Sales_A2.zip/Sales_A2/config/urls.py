from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('security/', include('security.urls')),
    path('purchases/', include('purchasing.urls')),
    path('empleados/', include('empleados.urls')),
    path('categoria/', include('categoria.urls')),
    path('departamento/', include('departamento.urls')),
    path('cobros/', include('cobros.urls')),
    path('pagos/', include('pagos.urls')),
    path('', include('billing.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

