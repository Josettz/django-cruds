from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('billing', '0006_alter_customer_dni'),
    ]

    operations = [
        migrations.AddField(
            model_name='invoice',
            name='saldo',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12, verbose_name='Saldo pendiente'),
        ),
        migrations.AddField(
            model_name='invoice',
            name='estado',
            field=models.CharField(
                choices=[('pendiente', 'PENDIENTE'), ('pagada', 'PAGADA'), ('anulada', 'ANULADA')],
                default='pendiente', max_length=10, verbose_name='Estado',
            ),
        ),
    ]
